const index = require('./index.js');

const event = {
    tableName: "CourseTable"
};

index.handler(event);