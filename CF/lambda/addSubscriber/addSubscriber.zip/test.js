const index = require('./index.js');

const event = {
    courseId: "CSCI5409",
    email: "sourav15102@iiitd.ac.in"
};

index.handler(event);